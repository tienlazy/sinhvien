-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 20, 2019 lúc 09:17 AM
-- Phiên bản máy phục vụ: 10.1.36-MariaDB
-- Phiên bản PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quanliquancaphe`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bill`
--

CREATE TABLE `bill` (
  `idBill` int(11) NOT NULL,
  `dateCheckIn` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateCheckOut` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idTableFood` int(11) NOT NULL,
  `billStatus` int(11) NOT NULL,
  `deleteValue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `bill`
--

INSERT INTO `bill` (`idBill`, `dateCheckIn`, `dateCheckOut`, `idTableFood`, `billStatus`, `deleteValue`) VALUES
(1, '2018-12-08', '2018-12-09', 1, 1, 1),
(2, '2018-12-13', '2018-12-14', 2, 1, 1),
(3, '2018-12-08', '2018-12-08', 3, 0, 0),
(4, '2018-12-06', '2018-12-07', 5, 0, 0),
(5, '2019-05-24', '2019-05-24', 6, 0, 0),
(43, '2019-01-13', '0000-00-00', 4, 1, 1),
(44, '2019-05-24', '0000-00-00', 6, 1, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `billinfo`
--

CREATE TABLE `billinfo` (
  `idBillInfo` int(11) NOT NULL,
  `idBill` int(11) NOT NULL,
  `idFood` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `billinfo`
--

INSERT INTO `billinfo` (`idBillInfo`, `idBill`, `idFood`, `count`) VALUES
(1, 1, 4, 3),
(2, 2, 1, 7),
(3, 3, 4, 2),
(4, 4, 3, 5),
(5, 5, 2, 26),
(81, 43, 14, 10),
(82, 5, 11, 10),
(83, 44, 3, 2),
(84, 44, 4, 2),
(85, 44, 4, 4),
(86, 44, 4, 4);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `employees`
--

CREATE TABLE `employees` (
  `idEmployees` int(11) NOT NULL,
  `username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneNumber` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeTown` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identityCard` int(10) NOT NULL,
  `deleteValue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `employees`
--

INSERT INTO `employees` (`idEmployees`, `username`, `fullName`, `age`, `address`, `phoneNumber`, `homeTown`, `identityCard`, `deleteValue`) VALUES
(1, 'admin', 'Hồ Văn Tiên', 23, 'Gia Lai', '0898183251', 'Quảng Nam', 231296057, 1),
(2, 'ohayotien', 'Vô Tâm', 18, 'Đà Nẵng', '0348282622', 'Đà Nẵng', 231296057, 1),
(3, 'camtien', 'Vô Tâm', 20, 'Đà Nẵng', '348282622', 'Đà Nẵng', 231296057, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `food`
--

CREATE TABLE `food` (
  `idFood` int(11) NOT NULL,
  `foodName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idFoodCategory` int(11) NOT NULL,
  `price` double NOT NULL,
  `deleteValue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `food`
--

INSERT INTO `food` (`idFood`, `foodName`, `idFoodCategory`, `price`, `deleteValue`) VALUES
(1, 'Cà phê sữa', 1, 12000, 1),
(2, 'Sữa chua', 2, 18000, 1),
(3, 'Trà đào', 3, 20000, 1),
(4, 'Kem trái cây', 4, 15000, 1),
(5, 'Sinh tố bơ', 5, 18000, 1),
(6, 'Coca', 6, 18000, 1),
(7, 'Pesi', 6, 20000, 1),
(8, 'Cà phê đen', 1, 12000, 1),
(9, 'Cà phê chocola', 1, 17000, 0),
(10, 'Cà phê sữa đá', 1, 18000, 1),
(11, 'Cà phê sài gòn', 1, 18000, 1),
(12, 'Cà phê rang say', 1, 12000, 1),
(13, 'Cà phê rang say', 1, 18000, 0),
(14, 'Cà phê rang say gia lai', 1, 12000, 0),
(15, 'Cà phê hạt', 1, 20000, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `foodcategory`
--

CREATE TABLE `foodcategory` (
  `idFoodCategory` int(11) NOT NULL,
  `foodCategoryName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleteValue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `foodcategory`
--

INSERT INTO `foodcategory` (`idFoodCategory`, `foodCategoryName`, `deleteValue`) VALUES
(1, 'Cà phê', 1),
(2, 'Sữa', 1),
(3, 'Trà', 1),
(4, 'Kem', 1),
(5, 'Sinh tố', 1),
(6, 'Nước giải khát', 1),
(7, 'Ăn hàng', 0),
(8, 'Ăn vặt nè', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tablefood`
--

CREATE TABLE `tablefood` (
  `idTableFood` int(11) NOT NULL,
  `tableName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tableStatus` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleteValue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tablefood`
--

INSERT INTO `tablefood` (`idTableFood`, `tableName`, `tableStatus`, `deleteValue`) VALUES
(1, '1', 'Có người', 1),
(2, '2', 'Có người', 1),
(3, '3', 'Có người', 1),
(4, '4', 'Có người', 1),
(5, '5', 'Có người', 1),
(6, '6', 'Có người', 1),
(7, '7', 'Trống', 1),
(8, '8', 'Trống', 1),
(9, '9', 'Trống', 1),
(10, '10', 'Trống', 1),
(11, '11', 'Trống', 1),
(12, '12', 'Trống', 1),
(13, '13', 'Trống', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `deleteValue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`username`, `password`, `type`, `deleteValue`) VALUES
('admin', 'admin', 1, 1),
('camtien', '123456', 1, 1),
('ohayotien', '123456', 1, 1),
('ohayotien1', 'hellotien', 1, 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`idBill`),
  ADD KEY `idTableFood` (`idTableFood`);

--
-- Chỉ mục cho bảng `billinfo`
--
ALTER TABLE `billinfo`
  ADD PRIMARY KEY (`idBillInfo`),
  ADD KEY `idBill` (`idBill`),
  ADD KEY `idFood` (`idFood`);

--
-- Chỉ mục cho bảng `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`idEmployees`),
  ADD KEY `username` (`username`);

--
-- Chỉ mục cho bảng `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`idFood`),
  ADD KEY `idFoodCategory` (`idFoodCategory`);

--
-- Chỉ mục cho bảng `foodcategory`
--
ALTER TABLE `foodcategory`
  ADD PRIMARY KEY (`idFoodCategory`);

--
-- Chỉ mục cho bảng `tablefood`
--
ALTER TABLE `tablefood`
  ADD PRIMARY KEY (`idTableFood`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bill`
--
ALTER TABLE `bill`
  MODIFY `idBill` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT cho bảng `billinfo`
--
ALTER TABLE `billinfo`
  MODIFY `idBillInfo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT cho bảng `employees`
--
ALTER TABLE `employees`
  MODIFY `idEmployees` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `food`
--
ALTER TABLE `food`
  MODIFY `idFood` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `foodcategory`
--
ALTER TABLE `foodcategory`
  MODIFY `idFoodCategory` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `tablefood`
--
ALTER TABLE `tablefood`
  MODIFY `idTableFood` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`idTableFood`) REFERENCES `tablefood` (`idTableFood`);

--
-- Các ràng buộc cho bảng `billinfo`
--
ALTER TABLE `billinfo`
  ADD CONSTRAINT `billinfo_ibfk_1` FOREIGN KEY (`idBill`) REFERENCES `bill` (`idBill`),
  ADD CONSTRAINT `billinfo_ibfk_2` FOREIGN KEY (`idFood`) REFERENCES `food` (`idFood`);

--
-- Các ràng buộc cho bảng `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`username`) REFERENCES `user` (`username`);

--
-- Các ràng buộc cho bảng `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `food_ibfk_1` FOREIGN KEY (`idFoodCategory`) REFERENCES `foodcategory` (`idFoodCategory`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
