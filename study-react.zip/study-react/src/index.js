import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import './style.css';
import Hello from './helloworld';
import Hi from './hello';
import JSX from './jsx';
import JSX_1 from './jsx-1';
import Inline_Style from './inline-style';
import Comment from './comment';
import Components from './components';
import Example from './state-full-example';
import State from './state';
import Props from './Props';
import DefaultProps from './defaultProps';
import StateAndProps from './state-and-props';
import SetState from './setState';
import ForceUpdate from './force-update';
import FindDomNode from './find-dom-node';
import Lifecycle_Methods from './lifecycle-methods';
import Form from './form';
import ComplexExample_Form from './complexForm';
import Example_Onclick from './example-onclick';
import Child_Events from './child-events';
import Using_Ref from './using-ref-getvalue';
import UsingRefClearValue from './using-ref-clearvalue';
import Key from './key';
import Animate from './animate';
import FilterableProductTable from './searchBar';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<Hello />, document.getElementById('helloworld'));
ReactDOM.render(<Hi />, document.getElementById('root'));
ReactDOM.render(<JSX />, document.getElementById('jsx'));
ReactDOM.render(<JSX_1 />, document.getElementById('jsx_1'));
ReactDOM.render(<Inline_Style />, document.getElementById('inline-style'));
ReactDOM.render(<Comment />, document.getElementById('comment'));
ReactDOM.render(<Components />, document.getElementById('components'));
ReactDOM.render(<Example />, document.getElementById('example'));
ReactDOM.render(<State />, document.getElementById('state'));
ReactDOM.render(<Props  headerProp="Đây là nội dung thứ nhất mà Props lấy từ cha xún" 
            contentProp="Đây là nội dung thứ hai mà Props lấy từ cha xún"/>, document.getElementById('props'));
ReactDOM.render(<DefaultProps />, document.getElementById('default-props'));
ReactDOM.render(<StateAndProps />, document.getElementById('state-and-props'));
ReactDOM.render(<SetState />, document.getElementById('SetState'));
ReactDOM.render(<ForceUpdate />, document.getElementById('force-update'));
ReactDOM.render(<FindDomNode />, document.getElementById('find-dom-node'));
ReactDOM.render(<Lifecycle_Methods />, document.getElementById('lifecycle-methods'));
setTimeout(() => {
    ReactDOM.unmountComponentAtNode(document.getElementById('lifecycle-methods'));}, 10000);
ReactDOM.render(<Form />, document.getElementById('form'));
ReactDOM.render(<ComplexExample_Form />, document.getElementById('complexexample-form'));
ReactDOM.render(<Example_Onclick />, document.getElementById('example-onclick'));
ReactDOM.render(<Child_Events />, document.getElementById('child-events'));
ReactDOM.render(<Using_Ref />, document.getElementById('using-ref'));   
ReactDOM.render(<UsingRefClearValue />, document.getElementById('ref-clear'));
ReactDOM.render(<Key />, document.getElementById('key'));
ReactDOM.render(<Animate />, document.getElementById('animate'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// ReactDOM.render(<Key />, document.getElementById('key'));
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
const PRODUCTS = [
    {category: 'Sporting Goods', price: '$49.99', stocked: true, name: 'Football'},
    {category: 'Sporting Goods', price: '$9.99', stocked: true, name: 'Baseball'},
    {category: 'Sporting Goods', price: '$29.99', stocked: false, name: 'Basketball'},
    {category: 'Electronics', price: '$99.99', stocked: true, name: 'iPod Touch'},
    {category: 'Electronics', price: '$399.99', stocked: false, name: 'iPhone 5'},
    {category: 'Electronics', price: '$199.99', stocked: true, name: 'Nexus 7'}
];
  
  ReactDOM.render(
    <FilterableProductTable products={PRODUCTS} />,
    document.getElementById('searchBar')
  );
serviceWorker.unregister();
