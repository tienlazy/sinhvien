import React from 'react';

class JSX extends React.Component {
    render() {
        return (
            <div>
                <h1>{10 + 5}</h1>
            </div>
        );
    }
}
//JSX được sử dụng bằng cách khai báo nó với hai dấu ngoặc nhọn {}
export default JSX;