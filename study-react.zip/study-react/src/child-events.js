import React from 'react';
/**
 * Khi ta muốn update state của component cha từ component con, ta tạo 1 event handler(updateState) ở component cha 
 * và chuyền nó xuống component con thông qua prop (updateStateProp). 
 */
class Child_Events extends React.Component {
   constructor(props) {
      super(props);
      
      this.state = {
         data: 'Dữ liệu đang được khởi tạo'
      }
      this.updateState = this.updateState.bind(this);
   };
   updateState() {
      this.setState({data: 'Dữ liệu được cập nhật từ component con'})
   }
   render() {
      return (
         <div>
            <Content myDataProp = {this.state.data} 
               updateStateProp = {this.updateState}></Content>
         </div>
      );
   }
}
class Content extends React.Component {
   render() {
      return (
         <div>
            <button onClick = {this.props.updateStateProp}>CLICK</button>
            <h3>{this.props.myDataProp}</h3>
         </div>
      );
   }
}
export default Child_Events;