import React from 'react';

/**
 * Lifecycle Methods
 * componentWillMount: đây là method sẽ được thực thi trước khi 1 component được render trên cả bên server và bên client.
 * componentDidMount: method này được thực thi khi 1 component được render trên client side. Đây là nơi các hàm AJAX requests, 
 * DOM or update state được thực thi. Method này cũng được sử dụng để kết nối với các JS Framework khác và các function với 
 * delayed execution như setTimeout or setInterval. 
 * componentWillReceiveProps: sẽ được thực thi ngay khi thuộc tính props được update và trước khi component được render lại. 
 * shouldComponentUpdate: sẽ trả về kết quả true or false. Phương thức này sẽ xác định 1 component có được update hay không. 
 * Mặc định giá trị này là true. Nếu ta không muốn component render lại sau khi update state hay props thì return giá trị thành false. 
 * componentWillUpdate: được gọi khi chúng ta update state của component trước khi nó render lại.
 * componentDidUpdate: sau khi componentWillUpdate ở trên được gọi xong thì đến lượt thằng này được gọi.
 * componentWillUnmount :được gọi khi chúng ta unmout 1 component kiểu như xóa nó khỏi react.
 */

class Lifecycle_Methods extends React.Component {
    constructor(props) {
       super(props);
       
       this.state = {
          data: 0
       }
       this.setNewNumber = this.setNewNumber.bind(this)
    };
    /** hàm setNewnumber sẽ được dùng để update state */
    setNewNumber() {
       this.setState({data: this.state.data + 1})
    }
    render() {
       return (
          <div>
             <button onClick = {this.setNewNumber}>INCREMENT</button>
             <Content myNumber = {this.state.data}></Content>
          </div>
       );
    }
 }
 /**các life cycle methods nằm trong content component */
 class Content extends React.Component {
     /**
      * Khi trang web được khởi tạo ta thấy nút button INCREMENT và số 0. 
      * Lúc này chỉ có 2 methods được thực thi, đó là componentWillMount và componentDidMount  
      * */
    componentWillMount() {
       console.log('Component WILL MOUNT!')
    }
    componentDidMount() {
       console.log('Component DID MOUNT!')
    }
    /**
     * Khi ta click vào button INCREMENT quá trình update state xảy ra và các life cycle methods khác sẽ được thực hiện
     * Đó là các methods: componentWillReceiveProps, componentDidUpdate và componentWillUpdate
     */
    componentWillReceiveProps(newProps) {    
       console.log('Component WILL RECIEVE PROPS!')
    }
    shouldComponentUpdate(newProps, newState) {
       return true;
    }
    componentWillUpdate(nextProps, nextState) {
       console.log('Component WILL UPDATE!');
    }
    componentDidUpdate(prevProps, prevState) {
       console.log('Component DID UPDATE!')
    }
    /**Bây giờ sau 10s(được set bên index.js) Lifecycle_Methods component sẽ bị unmount và method cuối cùng được thực hiện:
     * Đó là Method componentWillUnmount
     */
    componentWillUnmount() {
       console.log('Component WILL UNMOUNT!')
    }
    render() {
       return (
          <div>
             <h3>{this.props.myNumber}</h3>
          </div>
       );
    }
 }
 export default Lifecycle_Methods;