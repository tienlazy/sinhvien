import React from 'react';

class Hi extends React.Component {
    render() {
        return (
            <div>
                <h1>Good morning</h1>
                <h2>Ohayo gozaimasu</h2>
                <h3>Chào buổi sáng</h3> 
            </div>
        );
    }
}
//Trong ví dụ này, 3 element được bọc trong thẻ div. Nó là 1 container.
export default Hi;
