import React from 'react';
import ReactDOM from 'react-dom';

/**productTable(Hiển thị thông tin sản phẩm và lọc thông tin theo đầu vào của người dùng(searchBar)) */
class ProductTable extends React.Component {
    render() {
        /** Get dữ liệu từ component cha */
        const filterText = this.props.filterText;
        const inStockOnly = this.props.inStockOnly;
        const rows = [];
        let lastCategory = null;
        this.props.products.forEach((product) => {
            /**Kiểm tra giá trị đã get(filterText) xem có tồn tại trong mảng danh sách hay không*/
            if (product.name.indexOf(filterText) === -1) {
                return;
            }
            /**Kiểm tra giá trị đã get(inStockOnly) trả về true hay false*/
            if (inStockOnly && !product.stocked) {
                return;
            }
            /**Kiểm tra loại sản phẩm có null hay không.*/
            if (product.category !== lastCategory) {
                /**Nếu khác null thêm loại sản phẩm và key vào mảng đã khởi tạo */
                rows.push(
                    <ProductCategoryRow category={product.category} key={product.category}/>
                );
            }
            /**Thêm thông sản phẩm vào mảng đã khởi tạo */
            rows.push(
                <ProductRow product={product} key={product.name}/>
            );
            /** Gán loại sản phẩm để hiển thị 1 lần,nhằm tránh hiển thị loại sản phẩm nhiều lần theo mỗi sản phẩm */
            lastCategory = product.category;
        });
        /**Hiển thị sản phẩm */
        return (
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>{rows}</tbody>
            </table>
        );
    }
}
/** ProductCategoryRow(hiển thị tiêu đề loại sản phẩm) */
class ProductCategoryRow extends React.Component {
    /**Tiêu đề loại sản phẩm ở đây là: Sporting Goods và Electronics */
    render() {
        const category = this.props.category;
        return (
            <tr>
                <th colSpan="2">
                    {category}
                </th>
            </tr>
        );
    }
  }

  /**productRow(hiển thị hàng sản phẩm) */
class ProductRow extends React.Component {
    /**kiểm tra nếu sản phẩm có stocked = false thì tên của sản phẩm đó sẽ hiển thị màu đỏ */
    render() {
        const product = this.props.product;
        const name = product.stocked ? product.name :
        <span style={{color: 'red'}}>
            {product.name}
        </span>;
  
        return (
            <tr>
                <td>{name}</td>
                <td>{product.price}</td>
            </tr>
        );
    }
}

export default ProductTable;