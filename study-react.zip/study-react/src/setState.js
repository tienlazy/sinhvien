import React from 'react';
/**
 * setSate() methods được sử dụng để update state trong component
 * method này sẽ không tạo state mới mà chỉ update 1 state cũ có sẵn
 */
class SetState extends React.Component {
    constructor() {
        super();
        this.state = {
            data: []
        }
        /**Trong ES6 khi ta viết 1 function trong class, thì nó vẫn chưa được đinh nghĩa trong class,
         * ta phải định nghĩa nó trong constructor:  this.setStateHandler = this.setStateHandler.bind(this); 
         * */
        this.setStateHandler = this.setStateHandler.bind(this);
    }
    setStateHandler() {
        let item = "Set State";
        let myArr = this.state.data.slice();
        myArr.push(item); 
        this.setState({data: myArr});
    }
    /** ta bắt đầu với 1 chuỗi rỗng, mỗi lần chúng ta click vào button, state sẽ được update */
    render() {
        return (
            <div>
                <button onClick={this.setStateHandler}> Set State </button>
                <h4> State Arrays: {this.state.data}</h4>
            </div>
        );
    }
}

export default SetState;