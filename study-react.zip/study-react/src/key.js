import React from 'react';
import ReactDOM from 'react-dom';

/**
 * Key được sử dụng trong React khi một component return một mảng phần tử hoặc một danh sách các phần tử. 
 * Key giúp react xác định các phần tử trong mảng hoặc danh sách, phần tử nào đươc thêm vào, phần tử nào được update hay remove...
 * Lưu ý: là Key dùng để định danh các phần tử nên giá trị của nó cần duy nhất, không được trùng
 */

class Key extends React.Component {
    constructor() {
       super();
   
       this.state = {
          data:[
             {
                component: 'First...',
                id: 1
             },
             {
                component: 'Second...',
                id: 2
             },
             {
                component: 'Third...',
                id: 3
             }
          ]
       }
    }
    /**
     * Hàm map() nhận vào 3 tham số (theo thứ tự):
     * Phần tử hiện tại của mảng.
     * Chỉ số của phần tử hiện tại trong mảng.
     * Mảng ban đầu.
     */
    render() {
       return (
          <div>
             <div>
                {this.state.data.map((dynamicComponent, i) => <Content key = {i} componentData = {dynamicComponent}/>)}
             </div>
          </div>
       );
    }
 }
 class Content extends React.Component {
    render() {
       return (
          <div>
             <div>{this.props.componentData.component}</div>
             <div>{this.props.componentData.id}</div>
          </div>
       );
    }
 }
 export default Key;