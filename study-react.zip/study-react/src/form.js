import React from 'react';

/**
 * Ta sẽ khởi tạo 1 input form với value= {this.state.data}, dữ liệu trong form là state của component.
 *  Và ta sẽ update state khi ta thay đổi value trong input. Ta sẽ sử dụng sự kiện onChange đê kiểm tra 
 * sự thay đổi trong input và update lại state
 */
class Form extends React.Component {
   constructor(props) {
      super(props);
      
      this.state = {
         data: 'Dữ liệu đang được khởi tạo'
      }
      this.updateState = this.updateState.bind(this);
   };
   updateState(e) {
      this.setState({data: e.target.value});
   }
   render() {
      return (
         <div>
            <h1>Sử dụng state</h1>
            <input type = "text" value = {this.state.data} 
               onChange = {this.updateState} />
            <h4>{this.state.data}</h4>
         </div>
      );
   }
}
export default Form;