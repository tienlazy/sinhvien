import React from 'react';

class Using_Ref extends React.Component {
    constructor(props) {
        super(props);
        this.getInfo = this.getInfo.bind(this);
    }

    getInfo() {
        let text = this.refs.myInput.value;
        alert(text);
    }
    render() {
        return(
            <div>
                <input ref="myInput" type="text"/>
                <button onClick={this.getInfo}>Click</button>
            </div>
        );
    }
}

export default Using_Ref;