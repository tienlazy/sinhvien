import React from 'react';

/**
 * Ta có thể set default props cho component thay vì phải truyền vào lúc  reactDom.render() 
 */

 class DefaultProps extends React.Component {
    render() {
        return (
           <div>
              <h1>{this.props.headerProp}</h1>
              <h2>{this.props.contentProp}</h2>
           </div>
        );
     }
 }

 DefaultProps.defaultProps = {
    headerProp: "Header từ props",
    contentProp:"Content từ props"
 }
 export default DefaultProps;