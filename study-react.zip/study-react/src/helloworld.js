import React from 'react';
import { render } from '@testing-library/react';

class Hello extends React.Component {
    render() {
        return <h1>Hello world!</h1>;//
    }
}
//Chú ý: nếu muốn return nhiều element thì ta phải bọc nó với 1 container. 
//Ví dụ: Xem ở file hello.js
export default Hello;
