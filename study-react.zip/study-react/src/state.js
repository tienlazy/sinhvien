import React from 'react';

/**
 * State là nơi lưu trữ data trong ReactJs. Khi lập trình chúng ta nên đơn giản hóa state hết mức có thể và hạn 
 * chế số lượng components chứa state. Ví dụ nếu chúng ta có 10 components muốn có data từ state, chúng ta nên 
 * tạo một component và chứa state của 10 components kia.
 */
class State extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
           header: "Đây là header từ state",
           content: "Đây là content từ state"
        }
     }
     render() {
        return (
           <div>
              <h1>{this.state.header}</h1>
              <h2>{this.state.content}</h2>
           </div>
        );
     }
}

export default State;