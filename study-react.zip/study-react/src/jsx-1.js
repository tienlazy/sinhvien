import React from 'react';

class JSX_1 extends React.Component {
    render() {
        let i = 1;
        return (
            <div>
                <h1> {i == 1 ? 'True' : 'False'} </h1>
            </div>
        );
    }
}

//Chúng ta không thể sử dụng if, else trong JSX nhưng thay vì đó ta có thể làm như trên.
export default JSX_1;