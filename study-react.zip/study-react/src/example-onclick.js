import React from 'react';

class Example_Onclick extends React.Component {
    constructor(props) {
       super(props);
       
       this.state = {
          data: 'Dữ liệu đang được khởi tạo'
       }
       this.updateState = this.updateState.bind(this);
    };
    updateState() {
       this.setState({data: 'Dữ liệu đang cập nhật'})
    }
    /**sử dụng một component cùng với onClick event dùng để update state khi ta click vào button. */
    render() {
       return (
          <div>
             <button onClick = {this.updateState}>CLICK</button>
             <h4>{this.state.data}</h4>
          </div>
       );
    }
 }
 export default Example_Onclick;