import React from 'react';
import ReactDOM from 'react-dom';
/**
 * sử dung refs để xóa dữ liệu trong thẻ input bằng ClearInput function tìm kiếm 1 phần tử có ref=myInput thông ReactDom.findDomNode.
 */
class UsingRefClearValue extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: ""
        }
        this.updateState = this.updateState.bind(this);
        this.clearInput = this.clearInput.bind(this);
    }
    updateState(e) {
        this.setState({data: e.target.value});
    }

    clearInput(){
        this.setState({data: ""});
        ReactDOM.findDOMNode(this.refs.myInput).focus();
    }

    render() {
        return(
            <div>
                <h1>Clear Input</h1>
                <input value={this.state.data} onChange={this.updateState} ref="myInput"></input>
                <button onClick={this.clearInput}>Clear</button>
                <h4>{this.state.data}</h4>
            </div>
        );
    }

}

export default UsingRefClearValue;