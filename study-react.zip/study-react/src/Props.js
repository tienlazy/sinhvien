import React from 'react';

/**
 * Trong ReactJs ngoài state ra còn 1 hình thức lưu giữ data nữa đó là props, vậy props khác state như thế nào? 
 * Hiểu đơn giản là state thuộc về component(thuộc về cha), bạn có thể update, chỉnh sửa state, còn props cũng lưu dữ liệu như 
 * state nhưng được nhận từ component cha truyền xuống, bạn không thể chỉnh sửa trực tiếp props mà phải thay đổi từ cha nó
 */

 class Props extends React.Component {
    render() {
        return (
           <div>
              <h1>{this.props.headerProp}</h1>
              <h2>{this.props.contentProp}</h2>
           </div>
        );
     }
 }

 /**
  * Ta sẽ thấy giờ đây Props không còn state để giữ data để truyền vào 2 thẻ h1,h2 nữa mà thay vào đó lấy từ props.
  */
 export default Props;