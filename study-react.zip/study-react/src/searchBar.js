import React from 'react';
import ReactDOM from 'react-dom';
import ProductTable from './produc-table';

class SearchBar extends React.Component {
    constructor(props) {
        super(props);
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
        this.handleInStockChange = this.handleInStockChange.bind(this);
    }
    
    handleFilterTextChange(e) {
        this.props.onFilterTextChange(e.target.value);
    }

    handleInStockChange(e) {
        this.props.onInStockChange(e.target.checked);
    }

    render() {
        return(
            <form>
                <h1> Thinking In React </h1>
                <input type="text" placeholder="Search..." value={this.props.filterText}onChange={this.handleFilterTextChange}/>
                <p>
                    <input type="checkbox" onChange={this.handleInStockChange} checked={this.props.inStockOnly}></input> 
                    {' '} Only show products in stock
                </p>
            </form>
        );
    }
}


/**
 * Đây là component chứa tất cả thành phần còn lại bao gồm: searchBar(Đầu vào của người dùng, dùng để tìm kiếm thông tin), 
 * productTable(Hiển thị thông tin sản phẩm và lọc thông tin theo đầu vào của người dùng(searchBar)), 
 * productCategoryRow(hiển thị tiêu đề loại sản phẩm), productRow(hiển thị hàng sản phẩm)
 * */
class FilterableProductTable extends React.Component {
    constructor(props) {
        super(props);
        /**Khởi tạo 2 element là filterText mặc định là rỗng và inStockOnly là false*/
        this.state = {
            filterText: "",
            inStockOnly: false
        };
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
        this.handleInStockChange = this.handleInStockChange.bind(this);
    }

    /**Xử lý bộ lọc tìm kiếm theo name */
    handleFilterTextChange(filterText) {
        this.setState({
            filterText: filterText
        });
    }
    
    /**Xử lý bộ lọc tìm kiếm theo stocked */
    handleInStockChange(inStockOnly) {
        this.setState({
            inStockOnly: inStockOnly
        })
    }

    render() {
        return (
            <div>
                <SearchBar filterText={this.state.filterText} inStockOnly={this.state.inStockOnly} 
                onFilterTextChange={this.handleFilterTextChange} onInStockChange={this.handleInStockChange} />
                <ProductTable products={this.props.products} filterText={this.state.filterText} inStockOnly={this.state.inStockOnly}/>
            </div>
        );
    }
}

export default FilterableProductTable;