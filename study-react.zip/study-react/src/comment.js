import React from 'react';

class Comment extends React.Component {
    render() {
        return (
            <h1> Để sử dụng comment trong react ta sử dụng như sau: /* Trong này là nội dung comment */  </h1>
        );
    }
}

export default Comment;