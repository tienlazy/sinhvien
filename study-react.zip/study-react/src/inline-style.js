import React from 'react';

class Inline_Style extends React.Component {
    render() {
        let myStyle = {
            fontSize: 100,
            color: 'red'
        }
        return (
            <div>
                <h1 style = {myStyle}> Inline Style </h1>
            </div>
        );
    }
}
//Inline-style: Viết trực tiếp css lên thẻ tag
//Trong react khi sử dụng inline-style chúng ta nên dùng camelCase syntax. React sẽ tự động thêm 'px' vào sau các 
//giá trị số cho các element của css như: fontSize, width, height,...
export default Inline_Style;