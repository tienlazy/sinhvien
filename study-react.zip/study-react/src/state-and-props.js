import React from 'react';

/**
 * Sử dụng state và props cùng với nhau, ta sẽ khởi tạo state trong component cha và chuyền nó 
 * xuống các components con thông qua props.
 */
class StateAndProps extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            header: "Đây là header",
            content: "Đây là content"
        }
    }
    render() {
        return(
            <div>
                <Header headerProp={this.state.header} />
                <Content contentProp={this.state.content} />
            </div>
        );
    }
}

class Header extends React.Component {
    render() {
        return (
            <div>
                <h1>{this.props.headerProp}</h1>
            </div>
        );
    }
}

class Content extends React.Component {
    render() {
        return (
            <div>
                <h1>{this.props.contentProp}</h1>
            </div> 
        );
    }
}

export default StateAndProps;