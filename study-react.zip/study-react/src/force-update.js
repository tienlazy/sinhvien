import React from 'react';
/**
 * Thông thường React sẽ render lại component khi ta update state của nó, nhưng đôi lúc ta 
 * muốn tự tay update nó mà không thông qua state, khi đó ta cần đến Force Update
 */
class ForceUpdate extends React.Component {
    constructor(){
        super();
        this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    }
    forceUpdateHandler() {
        this.forceUpdate();
    }
    /**
     * Ta sẽ render ra 1 số bất kì mỗi khi bấm vào button.
     */
    render() {
        return (
            <div>
                <button onClick = {this.forceUpdateHandler}>FORCE UPDATE</button>
                <h4>Random number: {Math.random()}</h4>
            </div>
        );
    }
}

export default ForceUpdate;
