import { SHOW_CATEGORY } from '../../constants/ActionTypes'

const CATEGORIES = [
    {id: 1789, title: 'Điện Thoại, Máy Tính Bảng', isDsp: true},
    {id: 4221, title: 'Điện Tử - Điện Lạnh', isDsp: false},
    {id: 1815, title: 'Thiết Bị Số - Phụ Kiện Số', isDsp: false},
    {id: 1846, title: 'Laptop & Máy Vi Tính', isDsp: false},
    {id: 1801, title: 'Máy Ảnh Máy Quay Phim', isDsp: false},
    {id: 1882, title: 'Điện Gia Dụng', isDsp: false},
    {id: 1883, title: 'Nhà Cửa Đời Sống', isDsp: false},
    {id: 4384, title: 'Bách Hóa Online', isDsp: false},
    {id: 2549, title: 'Đồ chơi, Mẹ & Bé', isDsp: false},
    {id: 1520, title: 'Làm Đẹp - Sức Khỏe', isDsp: false},
    {id: 914, title: 'Thời Trang', isDsp: false},
    {id: 1975, title: 'Thể Thao & Dã Ngoại', isDsp: false},
    {id: 8594, title: 'Xe Máy, Ô tô, Xe Đạp', isDsp: false},
    {id: 8322, title: 'Nhà Sách Tiki', isDsp: false},
    {id: 11312, title: 'Voucher - Dịch Vụ', isDsp: false}
]

const getCategory = (state = CATEGORIES, action) => {
    if (action.type === SHOW_CATEGORY) {
        console.log(action.filter.id)
        var data = state.find(data => data.isDsp);
        data.isDsp = false;
        data = state.find(data => data.id === action.filter.id);
        data.isDsp = true;
        return [...state];
    }
    return state;
}

export default getCategory;