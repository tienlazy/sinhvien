import $ from 'jquery';
import { SHOW_CATEGORY, SHOW_PAGE, SEARCH_NAME } from '../../constants/ActionTypes';

const getList = (id, number, text) => {
  let datas
  $.ajax({
    url: 'https://tiki.vn/api/v2/events/deals/?category_ids='+id+'&type=now&page='+number+'&per_page=20',
    context: document.body,
    async: false
  }).done(function (data) {
    datas = data;
  });
  return {...datas, id: id, number: number, name: text}
}

const setAction = action => {
  if (!action.filter) {
    return inititalAction
  }
  return action;
}

const inititalAction = {
  type: '',
  filter: {
    id: '',
    number: 1,
    name: ''
  }
}

const listItems = (state, action) => {
  let number = 1;
  if (action.type === SHOW_CATEGORY) {
    return getList(action.filter.id, number)
  } 

  if(action.type === SHOW_PAGE) {
      return getList(state.id, action.filter.number)
  } 

  if (action.type === SEARCH_NAME) {
      const text = action.text.text;
      return getList(state.id, state.number, text)
  }
  action = setAction(action);
  return getList(action.filter.id, 1)
}

export default listItems