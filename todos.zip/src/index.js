import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import TikiApp from './components/TikiApp';
import store from './store';
import './index.scss';

const rootElement = document.getElementById('root');

render(
  <Provider store={store}>
    <TikiApp />
  </Provider>,
  rootElement
)

console.log(store.getState())