/**Hiển thị thành phần section và footer */
import React from 'react';
import Footer from './Footer';
import TodoList from './TodoList';
import { connect } from 'react-redux';
import * as TodoActions from '../actions';
import { bindActionCreators } from 'redux';
import { getCompletedTodoCount } from '../selectors';

const Section = ({ todosCount, completedCount, actions }) => (
  <section className="main">
    {
    !!todosCount && 
      <span>
        <input className="toggle-all" type="checkbox" checked={completedCount === todosCount} />
        <label onClick={actions.completeAllTodos}/>
      </span>
    }
    <TodoList />
    {
      !!todosCount &&
      <Footer completedCount={completedCount} activeCount={todosCount - completedCount} onClearCompleted={actions.clearCompleted}/>
      }
    </section>
  )

const mapStateToProps = state => ({
  todosCount: state.todos.length,
  completedCount: getCompletedTodoCount(state)
})
  
const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(TodoActions, dispatch)
})
  
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Section)