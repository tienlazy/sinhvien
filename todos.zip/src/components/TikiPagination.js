import React from 'react';
import { connect } from 'react-redux';
import Pagination from 'react-bootstrap/Pagination';
import { getPage } from '../actions';
// import PageItem from 'react-bootstrap/PageItem';

/* eslint-disable */
class Page extends React.Component {
    state = {
        flag: 1
    }
    handleClick = number => {
        this.setState({
            flag: number
        })
    }

    render() {
        const { get, handlePaging } = this.props;
        let active = 1;
        let items = [];
        const last_page = get.tiki.paging.last_page;
        let num = this.state.flag
        if(this.state.flag > 1) {
            items.push(<span className="prev" key={active - 1} onClick={() => handlePaging(this.state.flag - 1)}><i className="fa fa-angle-left"></i></span>)
            num = this.state.flag - 1
        }
        for (let number = 1; number <= last_page; number++) {
            items.push(
                <Pagination.Item key={number} className={(this.state.flag === number)? "current" : "normal"} onClick={() => { handlePaging(number); this.handleClick(number) }}>
                    {number}
                </Pagination.Item>
            );
        }
        if (this.state.flag < last_page) {
            items.push(<span className="next" key={last_page + 1} onClick={() => handlePaging(this.state.flag + 1)}><i className="fa fa-angle-right"></i></span>)
            num = this.state.flag + 1
        }
        return (
            <ul>
                <span>{items}</span>
            </ul>
        )
    }
}

const mapStateToProps = state => ({
    get: state
})

const mapDispatchToProps = (dispatch) => ({
    handlePaging: number => dispatch(getPage({
        number: number
    })),
})

export default connect(mapStateToProps, mapDispatchToProps)(Page);