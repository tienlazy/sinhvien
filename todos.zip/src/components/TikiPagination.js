import React from 'react';
import { connect } from 'react-redux';
import Pagination from 'react-bootstrap/Pagination';
import { getPage } from '../actions';

/* eslint-disable */
class Page extends React.Component {
    state = {
        flag: 1
    }
    handleClick = number => {
        this.setState({
            flag: number
        })
    }

    render() {
        const { get, handlePaging } = this.props;
        // let active = 1;
        let items = [];
        const last_page = get.tiki.paging.last_page;
        let num = this.state.flag
        // if(num > 1) {
        //     items.push(<span className="prev" key={active - 1} onClick={() => handlePaging(num - 1)}><i className="fa fa-angle-left"></i></span>)
        //     num = num - 1
        // }
        for (let number = 1; number <= last_page; number++) {
            if((number < num + 3) && (number > num -3)) {
                items.push(
                    <Pagination.Item key={number} className={(num === number)? "current" : "normal"} onClick={() => { handlePaging(number); this.handleClick(number) }}>
                        {number}
                    </Pagination.Item>
                );
            }
        }
        // if (num < last_page) {
        //     items.push(<span className="next" key={last_page + 1} onClick={() => handlePaging(num + 1)}><i className="fa fa-angle-right"></i></span>)
        //     num = num + 1
        // }
        return (
            <ul>
                <span>{items}</span>
            </ul>
        )
    }
}

const mapStateToProps = state => ({
    get: state
})

const mapDispatchToProps = (dispatch) => ({
    handlePaging: number => dispatch(getPage({
        number: number
    })),
})

export default connect(mapStateToProps, mapDispatchToProps)(Page);