import React from 'react';
import TikiSectionLeft from './TikiSectionLeft';
import TikiSectionRight from './TikiSectionRight';
import {Row} from 'reactstrap'

const Sections = () => {

    return (
        <div className="flex-container">
            <Row className="content">
                <TikiSectionLeft />
                <TikiSectionRight />
            </Row>
        </div>
    );
}

export default Sections;