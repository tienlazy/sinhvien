import React from 'react';
import TikiPagination from './TikiPagination';

/* eslint-disable */

const Footer = () => {
    return (
        <div className="flex-container">
            <div className="list-pager">
                <TikiPagination />
            </div>
        </div>
    )
}

export default Footer;