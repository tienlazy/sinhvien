import React from 'react';
import { connect } from 'react-redux';
import Pagination from 'react-bootstrap/Pagination';
import { getPage } from '../actions';
// import PageItem from 'react-bootstrap/PageItem';

/* eslint-disable */
const pagination = ({ get, handlePaging }) => {
    let active = 1;
    let items = [];
    const last_page = get.tiki.paging.last_page;
    for (let number = 1; number <= last_page; number++) {
        items.push(
            <Pagination.Item key={number} active={number === active} className={} onClick={() => handlePaging(number)}>
                {number}
            </Pagination.Item>,
        );
        if (number === active) {
            active = number
        }
    }
    console.log(active)
    return (
        <ul>
            <li><span className="prev"><i className="fa fa-angle-left"></i></span></li>
            {/* <li><span className="current">1</span></li> */}
            <li><span className="normal">{items}</span></li>
            <li><span className="next"><i className="fa fa-angle-right"></i></span></li>
        </ul>
    )
}

const mapStateToProps = state => ({
    get: state
})

const mapDispatchToProps = (dispatch) => ({
    handlePaging: number => dispatch(getPage({
        number: number
    })),
})

export default connect(mapStateToProps, mapDispatchToProps)(pagination);