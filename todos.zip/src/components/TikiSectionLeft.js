import React from 'react';
import { connect } from 'react-redux';
import {getCategory} from '../actions'
import {Col} from 'reactstrap';

/* eslint-disable */
class SectionLeft extends React.Component {
    state = {
        value: 0
    }
    handleClick(e) {
        this.setState({
            value: e.target.value
        })
    }
    render() {
        const {showCategory, handleCategory} = this.props
        const list = showCategory.map(filter => {
           return (
                <li key={filter.id}>
                    <label className="checkbox" filter={filter.id}>
                        <input className="checkbox" value={filter.id} type="checkbox" onClick={(e) => {handleCategory(filter.id); this.handleClick(e)}}></input>
                        <span className={this.state.value == filter.id ? "tikicon icon-check-on" : "tikicon icon-check-off"}></span> {filter.title}
                    </label>
                </li>
           )}
        )
        return(
            <Col sm="4" className="left">
            <div className="side-bar">
              <div className="head">NGÀNH HÀNG QUAN TÂM</div>
                <ul className="filter-category">
                    {list}
                </ul>
                </div>
            </Col>
        );
    }
}

const mapStateToProps = state => ({
    showCategory: state.category
})

const mapDispatchToProps = dispatch => ({
    handleCategory: id => dispatch(getCategory({
      id: id,
      number: 1,
      name: ''
    })),
})


export default connect(
    mapStateToProps,
    mapDispatchToProps
)(SectionLeft)