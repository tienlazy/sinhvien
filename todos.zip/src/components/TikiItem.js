import { connect } from 'react-redux';
import React from 'react';
import { Col, Row } from 'reactstrap';
import Countdown from 'react-countdown-now';

/* eslint-disable */
class list extends React.Component {
    state = {
        width: 0
    }
    render() {
        const { get, text } = this.props;
        let filterData = get.tiki.data.filter(item => item.product.name.includes(text));
        const eArabic = (x) => {
            return x.toLocaleString('de', { minimumFractionDigits: 0 })
        }
        let list
        if (filterData.length === 0) {
            let count
            let buy
            var today = new Date();
            list = get.tiki.data.map((obj, i) => {
                if (obj.progress.qty_ordered === 0) {
                    count = "Vừa mở bán";
                    buy = 0
                } else {
                    buy = (obj.progress.qty_ordered * 100) / obj.progress.qty
                    if (buy > 85) {
                        count = "Sắp bán hết";
                    } else {
                        count = "Đã bán " + obj.progress.qty_ordered;
                    }
                }
                const endDateSale = obj.special_to_date + "000";
                let offset = endDateSale - today.getTime()
                const renderer = ({ days, hours, minutes, seconds, completed }) => {
                    if (completed) {
                        return <span className="time"> 00 ngày 00:00:00 </span>
                    } else {
                        return <span className="time">{days} ngày {hours < 10 ? "0" + hours : hours}:{minutes < 10 ? "0" + minutes : minutes}:{seconds < 10 ? "0" + seconds : seconds}</span>;
                    }
                };
                return (
                    <a className="deal-item" key={i}>
                        <div className="image">
                            <div className="discount-badge">
                                -{obj.discount_percent}%
                                </div><img className="lazy" src={obj.product.thumbnail_url} style={{ width: '200px' }}></img></div>
                        <div className="title"><i className="tikicon icon-tikinow"></i>
                            {obj.product.name}
                        </div>
                        <div className="review-wrap">
                            <p className="rating"><span className="rating-content"><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i><span style={{ width: '86%' }}><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i></span></span>
                            </p>
                        </div>
                        <div className="price-sale">
                            {eArabic(obj.product.price)} đ
                            <span className="price-regular"> {eArabic(obj.product.list_price)} <span className="sizePrice"> {eArabic("đ")} </span></span></div>
                        <div className="deal-status">
                            <div className="process-bar">
                                <div style={{ width: buy }}></div><span className="text">{count}</span></div>
                            <div className="started">
                                <div className="deal-count-down">
                                    <Countdown
                                        date={Date.now() + offset}
                                        renderer={renderer}
                                    />
                                </div>
                            </div>
                        </div>
                    </a>
                )
            })
        } else {
            list = filterData.map((obj, i) => {
                return (
                    <a className="deal-item" key={i}>
                        <div className="image">
                            <div className="discount-badge">
                                -{obj.discount_percent}%
                                </div><img className="lazy" src={obj.product.thumbnail_url} style={{ width: '200px' }}></img></div>
                        <div className="title"><i className="tikicon icon-tikinow"></i>
                            {obj.product.name}
                        </div>
                        <div className="review-wrap">
                            <p className="rating"><span className="rating-content"><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i><span style={{ width: '86%' }}><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i><i className="star"></i></span></span>
                            </p>
                        </div>
                        <div className="price-sale">
                            {obj.product.price}
                            <span className="price-regular">{obj.product.list_price}</span></div>
                        <div className="deal-status">
                            <div className="process-bar">
                                <div style={{ width: '40.9%' }}></div><span className="text">{obj.progress.qty_ordered}</span></div>
                            <div className="started">
                                <div className="deal-count-down">
                                    <Countdown
                                        date={Date.now() + offset}
                                        renderer={renderer}
                                    />
                                </div>
                            </div>
                        </div>
                    </a>
                )
            })
        }
        return (
            <Col sm="8" className="right">
                <Row className="rows">
                    <div className="product-listing">
                        <div className="tabs">
                            <div className="tab-item active">ĐANG BÁN</div>
                            <div className="tab-item">SẮP BÁN</div>
                            <div className="tab-item">ĐANG THEO DÕI</div>
                            <div className="tab-item">CHÁY HÀNG</div>
                        </div>
                        <div className="items">
                            {list}
                        </div>
                    </div>
                </Row>
            </Col>
        );
    }
}


const mapStateToProps = (state) => ({
    get: state,
    text: state.tiki.name
})

export default connect(mapStateToProps)(list);