import React from 'react';
import Sections from './TikiSection';
import Header from './TikiHeader';
import Footer from './TikiFooter';
// import './index.css'

const TikiApp = () => {
    return(
        <div className="container-fluid">
            <Header />
            <Sections />
            <Footer />
        </div>
    );
}

export default TikiApp;