import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import TodoApp from './components/TodoApp';
import '../node_modules/todomvc-app-css/index.css';
import store from './store';

const rootElement = document.getElementById('root');

render(
  <Provider store={store}>
    <TodoApp />
  </Provider>,
  rootElement
)
