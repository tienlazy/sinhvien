/**Thành phần footer, hiển thị các filter và xử lí các action: hiển thị total item, hiển thị todos theo filter,  xóa toàn bộ todos đã checked*/
import React from 'react';
import LinK from './Link';
import { SHOW_ALL, SHOW_COMPLETED, SHOW_ACTIVE } from '../constants/TodoFilters';

const FILTER_TITLES = {
  [SHOW_ALL]: 'All',
  [SHOW_ACTIVE]: 'Active',
  [SHOW_COMPLETED]: 'Completed'
}

const Footer = (props) => {
  const { activeCount, completedCount, onClearCompleted } = props;
  const itemWord = activeCount === 1 ? 'item' : 'items';
  return (
    <footer className="footer">
      <span className="todo-count">
        <strong>{activeCount}</strong> {itemWord} left
      </span>
      <ul className="filters">
        {Object.keys(FILTER_TITLES).map(filter =>
          <li key={filter}>
            <LinK filter={filter}>
              {FILTER_TITLES[filter]}
            </LinK>
          </li>
        )}
      </ul>
      { !!completedCount &&<button className="clear-completed" onClick={onClearCompleted}>Clear completed</button>
        
      }
    </footer>
  )
}

export default Footer;
