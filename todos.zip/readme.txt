npm install
npm install redux
npm install react-redux
npm install --save-dev redux-devtools
npm install classnames
npm install --save redux-actions
npm install --save prop-types
npm install reselect