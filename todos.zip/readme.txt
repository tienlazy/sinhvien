npm install
npm install redux
npm install react-redux
npm install --save-dev redux-devtools
npm install classnames
npm install --save redux-actions
npm install --save prop-types
npm install reselect
npm install bootstrap
npm install --save reactstrap react react-dom
npm install jquery
npm install react-moment-countdown --save
npm install react-countdown-now --save