import { combineReducers } from 'redux'
import tiki from './tiki';
import category from './category';

const rootReducer = combineReducers({
  category,
  tiki
})

export default rootReducer
