import React from 'react';
import { connect } from 'react-redux';
import { searchName } from '../actions';

class Header extends React.Component {
    render() {
        const { handleSearch } = this.props;
        return (
            <div className="jumbotron text-center">
                <h1><strong className="headertitle">Tiki</strong> khuyễn mãi hot</h1>
                <input
                    className="form-control"
                    placeholder="Tìm tên sản phẩm mong muốn..."
                    onChange={(e) => handleSearch(e.target.value)}
                    value={this.props.value} />
            </div>
        );
    }
}

const mapDispatchToProps = dispatch => ({
    handleSearch: text => dispatch(searchName({
        text: text,
    })),
})

export default connect(
    null,
    mapDispatchToProps
)(Header)