/**Xử lí khi người dùng checked, click double, delete todos */
import React, { Component } from 'react';
import classnames from 'classnames';

export default class TodoItem extends Component {
  state = {
    editing: false
  }

  /**Xử lý khi người dùng click 2 lần vào content */
  handleDoubleClick = () => {
    this.setState({ 
      editing: true 
    })
  }

  /**Check khi người dùng thay đổi nội dung */
  handleSave = (id, text) => {
    if (text.length === 0) {
      this.props.deleteTodo(id);
    } else {
      this.props.editTodo(id, text);
    }
    this.setState({ 
      editing: false 
    })
  }

  render() {
    const { todo, completeTodo, deleteTodo } = this.props;
    return (
      <li className={classnames({ 
        completed: todo.completed, 
        editing: this.state.editing 
      })}>
        <div className="view">
          <input className="toggle" type="checkbox" checked={todo.completed} onChange={() => completeTodo(todo.id)} />
          <label onDoubleClick={this.handleDoubleClick}> {todo.text}</label>
          <button className="destroy" onClick={() => deleteTodo(todo.id)} />
        </div> 
      </li>
    )
  }
}
