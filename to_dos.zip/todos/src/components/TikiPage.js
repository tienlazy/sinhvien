import React from 'react';
import { connect } from 'react-redux';
import Pagination from 'react-js-pagination';
import { getPage } from '../actions';

/* eslint-disable */
class TikiPage extends React.Component {
    state = {
        activePage: 1
    }
    
    handleClick = pageNumber => {
        this.setState({
            activePage: pageNumber
        })
    }
    render() {
        const { get, handlePaging } = this.props;
        const last_page = get.tiki.paging.last_page;
        return (
            <ul>
                <span>
                    <Pagination
                        hideDisabled
                        activePage={this.state.activePage}
                        totalItemsCount={last_page}
                        pageRangeDisplayed={5}
                        onChange={this.handleClick}
                        onClick={() => handlePaging(this.state.activePage)}
                    />
                </span>
            </ul>
        )
    }
}

const mapStateToProps = state => ({
    get: state
})

const mapDispatchToProps = (dispatch) => ({
    handlePaging: number => dispatch(getPage({
        number: number
    })),
})

export default connect(mapStateToProps, mapDispatchToProps)(TikiPage);