import React from 'react';
import TikiItem from './TikiItem'

/* eslint-disable */
const SectionRight = () => {
    return(
        <div className="column middle">
            <div className="w3-row w3-grayscale">
                <TikiItem />
             </div>        
        </div>
    )
}

export default SectionRight;