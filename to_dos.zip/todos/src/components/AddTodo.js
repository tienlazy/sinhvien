/**Thành phần thêm todos */
import React, { Component } from 'react';

export default class AddTodo extends Component {
  state = {
    text: this.props.text
  }

  /**Xử lý khi người dùng nhấn phím enter */
  handleKeyDown = e => {
    const text = e.target.value.trim();
    if (e.which === 13) {
      this.props.onSave(text);
      this.setState({ text: '' })
    }
  }

  /**Xử lý khi người dùng nhập vào */
  handleChange = e => {
    this.setState({ text: e.target.value })
  }

  render() {
    return (
      <input className="new-todo"
        type="text" placeholder="What needs to be done?" value={this.state.text} onChange={this.handleChange}
        onKeyDown={this.handleKeyDown} autoFocus/>
    )
  }
}
