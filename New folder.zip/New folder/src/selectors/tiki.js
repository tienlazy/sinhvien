import { createSelector } from 'reselect';
import { SHOW_1708, SHOW_4221, SHOW_1815, SHOW_1846, 
    SHOW_1801, SHOW_1882, SHOW_1883, SHOW_4384, SHOW_2549, 
    SHOW_1520, SHOW_914, SHOW_1975, SHOW_8594, SHOW_8322, SHOW_11312} from '../constants/TodoFilters';

const getVisibilityFilter = state => state.visibilityFilter
const getTiki = state => state.tiki

export const getVisibleTodos = createSelector (
  [getVisibilityFilter, getTiki],
  (visibilityFilter, tiki) => {
    switch (visibilityFilter) {
        case SHOW_ALL:
            return tiki;
        case SHOW_1708:
            return tiki.filter(t => t.completed);
        case SHOW_4221:
            return tiki.filter(t => !t.completed);
        case SHOW_1815:
            return tiki;
        case SHOW_1846:
            return tiki.filter(t => t.completed);
        case SHOW_1801:
            return tiki.filter(t => !t.completed);    
        case SHOW_1882:
            return tiki.filter(t => t.completed);
        case SHOW_1883:
            return tiki.filter(t => !t.completed); 
        case SHOW_4384:
            return tiki.filter(t => t.completed);
        case SHOW_2549:
            return tiki.filter(t => !t.completed); 
        case SHOW_1520:
            return tiki.filter(t => t.completed);
        case SHOW_914:
            return tiki.filter(t => !t.completed); 
        case SHOW_1975:
            return tiki.filter(t => t.completed);
        case SHOW_8594:
            return tiki.filter(t => !t.completed);   
        case SHOW_8322:
            return tiki.filter(t => !t.completed);   
        case SHOW_11312:
            return tiki.filter(t => !t.completed);    
      default:
        throw new Error('Unknown filter: ' + visibilityFilter);
    }
  }
)
