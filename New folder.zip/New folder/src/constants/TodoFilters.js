/**
 * Xác định các loại filter action
 */
export const SHOW_ALL = 'show_all'
export const SHOW_COMPLETED = 'show_completed'
export const SHOW_ACTIVE = 'show_active'
export const SHOW_1708 = 'SHOW_1708'
export const SHOW_4221 = 'SHOW_4221'
export const SHOW_1815 = 'SHOW_1815'
export const SHOW_1846 = 'SHOW_1846'
export const SHOW_1801 = 'SHOW_1801'
export const SHOW_1882 = 'SHOW_1882'
export const SHOW_1883 = 'SHOW_1883'
export const SHOW_4384 = 'SHOW_4384'
export const SHOW_2549 = 'SHOW_2549'
export const SHOW_1520 = 'SHOW_1520'
export const SHOW_914 = 'SHOW_914'
export const SHOW_1975 = 'SHOW_1975'
export const SHOW_8594 = 'SHOW_8594'
export const SHOW_8322 = 'SHOW_8322'
export const SHOW_11312 = 'SHOW_11312'

