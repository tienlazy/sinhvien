import React from 'react';
import TikiSectionLeft from './TikiSectionLeft';
import TikiSectionRight from './TikiSectionRight';

const Sections = () => {
    return(
        <div className="row">
            <TikiSectionLeft />
            <TikiSectionRight />
        </div>
    );
}

export default Sections;