import React from 'react';
import { connect } from 'react-redux';
/* eslint-disable */
const SectionRight = ({state}) => {
    console.log(state.tiki[0].product)
    return(
        <div className="column middle">
            <div classname="w3-row w3-grayscale">
                <div className="w3-col l3 s6">
                        <img src="/w3images/jeans1.jpg" alt="true" style={{width: '100%'}} />
                        <p>Ripped Skinny Jeans<br /><b>$24.99</b></p>
                </div>
             </div>        
        </div>
    )
}

const mapStateToProps = state => ({
    state
})

export default connect(mapStateToProps)(SectionRight);