import React from 'react';
import { SHOW_1708, SHOW_4221, SHOW_1815, SHOW_1846, 
    SHOW_1801, SHOW_1882, SHOW_1883, SHOW_4384, SHOW_2549, 
    SHOW_1520, SHOW_914, SHOW_1975, SHOW_8594, SHOW_8322, SHOW_11312} from '../constants/TodoFilters';

const CATEGORIES = {
    [SHOW_1708]: "Điện Thoại, Máy Tính Bảng",
    [SHOW_4221]: "Điện Tử - Điện Lạnh",
    [SHOW_1815]: "Thiết Bị Số - Phụ Kiện Số",
    [SHOW_1846]: "Laptop & Máy Vi Tính",
    [SHOW_1801]: "Máy Ảnh Máy Quay Phim",
    [SHOW_1882]: "Điện Gia Dụng",
    [SHOW_1883]: "Nhà Cửa Đời Sống",
    [SHOW_4384]: "Bách Hóa Online",
    [SHOW_2549]: "Đồ chơi, Mẹ & Bé",
    [SHOW_1520]: "Làm Đẹp - Sức Khỏe",
    [SHOW_914]: "Thời Trang",
    [SHOW_1975]: "Thể Thao & Dã Ngoại",
    [SHOW_8594]: "Xe Máy, Ô tô, Xe Đạp",
    [SHOW_8322]: "Nhà Sách Tiki",
    [SHOW_11312]: "Voucher - Dịch Vụ"
}

const SectionLeft = () => {
    return(
        <div className="column side">
            {Object.keys(CATEGORIES).map(filter =>
                <li key={filter}>
                    <input type="checkbox"></input>
                    <span>
                        {CATEGORIES[filter]}
                    </span>
                </li>
            )}
        </div>
    );
}


export default SectionLeft;