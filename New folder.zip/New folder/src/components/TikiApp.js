import React from 'react';
import Sections from './TikiSection';
import Header from './TikiHeader';
import './index.css'

const TikiApp = () => {
    return(
        <div className="container-fluid">
            <Header />
            <Sections />
        </div>
    );
}

export default TikiApp;