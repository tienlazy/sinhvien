import React from 'react';

const Header = () => {
    return(
        <div className="header">
            <input type="text"></input>
            Search
        </div>
    );
}

export default Header;