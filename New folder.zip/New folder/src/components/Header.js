/**Thành phần header */
import React from 'react';
import AddTodo from './AddTodo';
import { connect } from 'react-redux';
import { addTodo } from '../actions';

const Header = ({ addTodo }) => (
  <header className="header">
    <h1>todos</h1>
    <AddTodo onSave={(text) => {
        if (text.length !== 0) {
          addTodo(text)
        }
      }}
    />
  </header>
)

export default connect(null, { addTodo })(Header)
