import $ from 'jquery';

const getList = () => {
    let list
    $.ajax({
        url: "https://tiki.vn/api/v2/events/deals/?category_ids=&type=now&page=1&per_page=20",
        dataType: 'json',
        async: false,
        success: function(data) {
          list = data.data
        }
    });
    return list
}

export default getList;