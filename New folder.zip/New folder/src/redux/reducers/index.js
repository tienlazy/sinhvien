import { combineReducers } from 'redux'
// import todos from './todos'
// import visibilityFilter from './visibilityFilter'
import tiki from './tiki';

const rootReducer = combineReducers({
  // todos,
  // visibilityFilter, tiki
  tiki
})

export default rootReducer
